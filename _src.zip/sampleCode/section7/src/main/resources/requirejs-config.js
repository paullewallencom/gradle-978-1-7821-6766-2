requirejs.config({    
baseUrl: ".",    
packages: [
        {
            "name": "jquery",
            "location": "jam/jquery",
            "main": "dist/jquery.js"
			}    ],
name: "main",    
out: "main-built.js"}) 
