function miscUtility()
{
alert("utility!");
}